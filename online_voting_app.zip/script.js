
// Store users and votes in localStorage
let users = JSON.parse(localStorage.getItem("users")) || [];
let votes = JSON.parse(localStorage.getItem("votes")) || {
    "Candidate A": 0,
    "Candidate B": 0,
    "Candidate C": 0
};

// Show sections
function showLogin() {
    document.getElementById("login-section").style.display = "block";
    document.getElementById("register-section").style.display = "none";
    document.getElementById("vote-section").style.display = "none";
    document.getElementById("result-section").style.display = "none";
}

function showRegister() {
    document.getElementById("login-section").style.display = "none";
    document.getElementById("register-section").style.display = "block";
}

function showVote() {
    document.getElementById("login-section").style.display = "none";
    document.getElementById("vote-section").style.display = "block";
}

function showResults() {
    document.getElementById("vote-section").style.display = "none";
    document.getElementById("result-section").style.display = "block";

    const resultsList = document.getElementById("results-list");
    resultsList.innerHTML = "";

    for (let candidate in votes) {
        const listItem = document.createElement("li");
        listItem.textContent = `${candidate}: ${votes[candidate]} votes`;
        resultsList.appendChild(listItem);
    }
}

// Register function
function register() {
    const username = document.getElementById("reg-username").value;
    const password = document.getElementById("reg-password").value;

    if (users.some(user => user.username === username)) {
        alert("Username already exists!");
        return;
    }

    users.push({ username, password, hasVoted: false });
    localStorage.setItem("users", JSON.stringify(users));
    alert("Registration successful! Please log in.");
    showLogin();
}

// Login function
function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        if (user.hasVoted) {
            alert("You have already voted!");
            showResults();
        } else {
            alert("Login successful! Please cast your vote.");
            showVote();
        }
    } else {
        alert("Invalid username or password!");
    }
}

// Cast vote function
function castVote() {
    const selectedCandidate = document.querySelector('input[name="candidate"]:checked');
    if (!selectedCandidate) {
        alert("Please select a candidate!");
        return;
    }

    const username = document.getElementById("username").value;
    const userIndex = users.findIndex(user => user.username === username);

    if (userIndex !== -1) {
        users[userIndex].hasVoted = true;
        votes[selectedCandidate.value]++;
        localStorage.setItem("users", JSON.stringify(users));
        localStorage.setItem("votes", JSON.stringify(votes));

        alert("Vote cast successfully!");
        showResults();
    }
}

// Reset function for testing/demo purposes
function resetApp() {
    localStorage.clear();
    users = [];
    votes = {
        "Candidate A": 0,
        "Candidate B": 0,
        "Candidate C": 0
    };
    alert("Voting reset!");
    showLogin();
}
    